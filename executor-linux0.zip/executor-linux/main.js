const { app, BrowserWindow, ipcMain, Tray, Menu, shell, dialog } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');
const https = require('https');

let mainWindow;
let updateWindow;
let backendProcess = null;
let tray = null;

// Set current app version
const CURRENT_VERSION = "1.0.0"; // Change this when you update the app
const VERSION_URL = "https://raw.githubusercontent.com/conscious-stage/executor-download/refs/heads/main/version.json";

// Function to check for updates
async function checkForUpdates() {
    try {
        const response = await new Promise((resolve, reject) => {
            https.get(VERSION_URL, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const versionData = JSON.parse(data);
                        resolve(versionData);
                    } catch (error) {
                        reject("Error parsing version data.");
                    }
                });
            }).on('error', reject);
        });

        if (response.latest !== CURRENT_VERSION) {
            return response; // New version available
        }
        return null; // Already up to date
    } catch (error) {
        console.error('Update check failed:', error);
        return null; // If update check fails, proceed without update
    }
}

// Function to create the update window
function createUpdateWindow(downloadUrl) {
    updateWindow = new BrowserWindow({
        width: 350,
        height: 350,
        resizable: false,
        modal: true,
        show: false,
        icon: path.join(__dirname, 'renderer', 'assets', 'icon.png'),
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false
        }
    });

    updateWindow.loadFile(path.join(__dirname, 'renderer', 'update.html'));

    updateWindow.once('ready-to-show', () => {
        updateWindow.show();
    });

    updateWindow.webContents.once('did-finish-load', () => {
        updateWindow.webContents.send('set-download-url', downloadUrl);
    });
    updateWindow.removeMenu();
}
ipcMain.handle('open-external-url', async (event, url) => {
    return shell.openExternal(url);
  });
// Function to create the main app window
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 700,
        height: 510,
        resizable: false,
        icon: path.join(__dirname, 'renderer', 'assets', 'icon.png'),
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false
        },
        backgroundColor: '#131313'
    });

    mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

    mainWindow.webContents.on('did-finish-load', () => {
        mainWindow.webContents.insertCSS('body { overflow: hidden; }');
    });

    mainWindow.on('close', (event) => {
        event.preventDefault();
        mainWindow.hide();
    });
}

// Initialize the app
app.whenReady().then(async () => {
    try {
        const updateInfo = await checkForUpdates();
        if (updateInfo) {
            createUpdateWindow(updateInfo.download_url);
        } else {
            createWindow();
            createTray();
        }
    } catch (error) {
        console.error("Error checking for updates:", error);
        createWindow(); // Open app even if update check fails
        createTray();
    }

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

// Function to create system tray
function createTray() {
    tray = new Tray(path.join(__dirname, 'renderer', 'assets', '32x32.png'));
    const contextMenu = Menu.buildFromTemplate([
        { label: 'Open', click: () => mainWindow.show() },
        { label: 'Disconnect', click: () => stopBackendProcess() },
        { label: 'Quit', click: () => { stopBackendProcess();app.quit();app.exit(0); } }
    ]);
    tray.setToolTip('Executor');
    tray.setContextMenu(contextMenu);
    tray.on('click', () => mainWindow.show());
}

// Function to stop backend process
function stopBackendProcess() {
    if (backendProcess) {
        console.log('Stopping backend process...');
        backendProcess.kill();
        backendProcess = null;
    }
}

// Quit when all windows are closed
app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        stopBackendProcess();
        app.quit();
    }
});

// Function to start the backend process
function startBackendProcess(machineKey) {
    const isPackaged = app.isPackaged;
    const platform = process.platform;

    let backendFilename;

    if (platform === 'win32') {
        backendFilename = 'server.exe';
    } else if (platform === 'linux' || platform === 'darwin') {
        backendFilename = 'server.bin';
    } else {
        mainWindow.webContents.send('log-message', `Unsupported platform: ${platform}`);
        return false;
    }

    // Point to backend/server.dist/server.exe or server
    const backendPath = isPackaged
        ? path.join(process.resourcesPath, 'backend', 'server.dist', backendFilename)
        : path.join(__dirname, 'backend', 'server.dist', backendFilename);

    // Debug: log exact path
    console.log("Backend path:", backendPath);

    // Check if the file exists
    if (!fs.existsSync(backendPath)) {
        mainWindow.webContents.send('log-message', `❌ Backend binary not found at: ${backendPath}`);
        return false;
    }

    const spawnOptions = {};

    if (platform !== 'win32') {
        spawnOptions.shell = true; // Needed to spawn on Linux/macOS
    }

    backendProcess = spawn(backendPath, [machineKey], spawnOptions);

    backendProcess.stdout.on('data', (data) => {
        mainWindow.webContents.send('log-message', data.toString());
    });

    backendProcess.stderr.on('data', (data) => {
        const msg = data.toString();
        if (msg.toLowerCase().includes('error')) {
            mainWindow.webContents.send('log-message', `❌ ${msg}`);
            mainWindow.webContents.send('connection-status', 'error');
        } else {
            mainWindow.webContents.send('log-message', msg);
        }
    });

    backendProcess.on('close', (code) => {
        console.log(`Backend exited with code ${code}`);
        backendProcess = null;
        mainWindow.webContents.send('connection-status', 'disconnected');
    });

    return true;
}

// IPC handlers for communication with renderer
ipcMain.handle('connect', async (event, machineKey) => {
    mainWindow.webContents.send('log-message', 'Attempting to connect...');

    if (backendProcess) {
        stopBackendProcess();
    }

    const success = startBackendProcess(machineKey);
    if (success) {
        mainWindow.webContents.send('connection-status', 'connected');
        return { success: true };
    } else {
        mainWindow.webContents.send('connection-status', 'error');
        return { success: false, error: 'Failed to start backend process' };
    }
});

ipcMain.handle('disconnect', async () => {
    mainWindow.webContents.send('log-message', 'Disconnecting...');
    stopBackendProcess();
    mainWindow.webContents.send('connection-status', 'disconnected');
    return { success: true };
});
